<?php

namespace APP\Repository;

class ClientRepository extends Repository {
    
}



